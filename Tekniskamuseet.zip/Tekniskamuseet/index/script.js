// set up the canvas and context
var canvas = document.querySelector("canvas");
var ctx = canvas.getContext("2d");
canvas.height = document.documentElement.clientHeight;
canvas.width = document.documentElement.clientWidth;


function lights(x, y, dx, dy, radius){
    this.x = x;
    this.y = y;
    this.dx = dx;
    this.dy = dy;
    this.radius = radius; 

    this.drawLights = function(){
        ctx.beginPath();
        ctx.arc(this.x, this.y, this.radius, 0, Math.PI * 2, false);
        ctx.fillStyle = 'rgb('+ Math.floor(Math.random()*256)+','+ Math.floor(Math.random()*256)+','+Math.floor(Math.random()*256)+')';
        ctx.fill();
    }


    this.update = function(){
        if(this.x + this.radius > canvas.width || this.x - this.radius < 0){
            this.dx = -this.dx;
        }
        

        if(this.y + this.radius > canvas.height || this.y - this.radius < 0){
            this.dy = -this.dy;
        }
        
        this.x += this.dx;
        this.y += this.dy;

        this.drawLights();
    }
}
lightsArray = [];
for(i = 0; i < 100; i++){
    let x = Math.random() * canvas.width;
    let y = Math.random() * canvas.height;
    let dx = Math.random() - 0.5; 
    let dy = Math.random() - 0.5;
    let radius = Math.PI *2
    lightsArray.push(new lights(x, y, dx, dy, radius))

    console.log(lightsArray)
}

function animate(){

    requestAnimationFrame(animate)
    ctx.clearRect(0,0,canvas.width, canvas.height);

    for(i=0; i<lightsArray.length; i++){
        lightsArray[i].update();
    }
}

animate();
